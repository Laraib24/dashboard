import "./App.css";
import Navbar from "./Components/Navbar/Navbar";
import Sidebar from "./Components/Sidebar/Sidebar";
import Log from "./Components/Log/Log";
import Announcements from "./Components/LatestAnnouncements/Latest";
import Accounting from "./Components/Accounting/Accounting";

function App() {
  return (
    <div className="App">
      <Navbar />
      <Sidebar />
      <Announcements />
      <Accounting />
      <Log />
      <img
        className="image"
        src="images\wesentinel-dashboard[1460].png"
        alt="dsd"
      />
    </div>
  );
}

export default App;
